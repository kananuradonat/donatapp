package com.donat.classworkapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class options extends AppCompatActivity {
    int pausedi;
    MediaPlayer playi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }


        });



      /*  Button bn;
        bn=(Button)findViewById(R.id.toasti);
        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(), "sorry no login page", Toast.LENGTH_LONG).show();


            }
        });*/






        Button logb=(Button)findViewById(R.id.toasti);
        Button cancel=(Button)findViewById(R.id.cancel);
        logb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog dialog=new Dialog(options.this);
                dialog.setContentView(R.layout.activity_music);
                dialog.show();
                final EditText usern=(EditText)dialog.findViewById(R.id.ed);
                Button login=(Button)dialog.findViewById(R.id.bt1);
                login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text = usern.getText().toString();
                        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG).show();


                    }
                });


            }
        });

    }
    public  void  show (View view) {
        Button bn;
        bn = (Button) findViewById(R.id.btn1);
        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(options.this);
                builder.setMessage("Are you sure to go back ?").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                finish();

                            }

                        })
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setTitle("MESSAGE DIALOG ");
                alert.show();


            }
        });
    }





    public void play (View v)
    {if(playi==null){playi= MediaPlayer.create(this, R.raw.sg);
        playi.start();}
    else if(!playi.isPlaying()) {playi.seekTo(pausedi);
        playi.start();}}
    public void stop (View v)
    {
       playi.release();
        playi=null;}
    public void pause (View v)
    {
        playi.pause();
        pausedi=playi.getCurrentPosition();

    }


}
